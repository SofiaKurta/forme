Subtle Patterns
===============

View all the patterns from [Subtle Patterns](https://www.toptal.com/designers/subtlepatterns/) - including the famous Photoshop .pat file.

If you need Base64 versions of the patterns, you can use this generator:
http://www.greywyvern.com/code/php/binary2base64.

The original authors of the patterns are credited on Subtle Patterns. Subtle Patterns is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License. The patterns here can be used free of charge, but please read this before using them: [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/).

[Subtle Patterns](https://www.toptal.com/designers/subtlepatterns/) © 2017 [Toptal](https://www.toptal.com).
